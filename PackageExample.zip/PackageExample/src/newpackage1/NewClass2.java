
package newpackage1;

public class NewClass2 {
    void showdata(){
        System.out.println("NewClass2");
    }    
}
