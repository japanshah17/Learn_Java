package newpackage1.subpackage1;

public class subpackageclass {
     void showdata(){
        System.out.println("NewClass2");
    }
}
