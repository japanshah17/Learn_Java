package newpackage1;

public class NewClass1 {
    public void showdata(){
        System.out.println("NewClass1");
    }
}
