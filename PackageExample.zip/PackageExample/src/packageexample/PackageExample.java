
package packageexample;

import newpackage1.*;
import newpackage1.subpackage1.subpackageclass;
// also we can import both class by.. 
//import newpackage1.NewClass1;
//import newpackage1.NewClass1;
public class PackageExample {
    public static void main(String[] args) {
            NewClass1 obj = new NewClass1();
            NewClass2 ob = new NewClass2(); // also can be written as New.NewClass2 ob = new  PackageExample.NewClass2();
            obj.showdata();
            subpackageclass o = new subpackageclass(); // if you comment out the 5th line. it will show you an error because you need to import the class of the subpackage explicitely. 
    }
}
